#include <stdio.h>

int main()
{
    enum myval {
        val23 = 23,
        val764 = 764,
        val7 = 7
    } foo;

    foo = val23;
    printf("foo is %d\n", foo);

    foo = (enum myval) (17);
    printf("foo is %d\n", foo);
     
}
