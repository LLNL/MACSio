/*********************************************************************************************
 *  Copyright (c) 2014-2015, RWTH Aachen University, JARA - Juelich Aachen Research Alliance.
 *  Produced at the RWTH Aachen University, Germany.
 *  Written by Jens Henrik Göbbert (goebbert@jara.rwth-aachen.de)
 *  All rights reserved.
 *
 *  This file is part of the H5zfp library.
 *  For details, see http://www.jara.org/de/research/jara-hpc/.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the disclaimer below.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the disclaimer (as noted below) in the
 *  documentation and/or other materials provided with the distribution.
 *
 *  3. Neither the name of the University nor the names of its contributors may
 *  be used to endorse or promote products derived from this software without
 *  specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************************************/
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string.h>
#include <assert.h>

#include "H5Tpublic.h"
#include "H5PLextern.h"

#include "zfp_h5filter.h"

#include "zfp.h"

#define PUSH_ERR(func, minor, str)                                      \
    H5Epush1(__FILE__, func, __LINE__, H5E_PLINE, minor, str)

/*-------------------------------------------------------------------------
 *
 *
 *
 *
 *
 *------------------------------------------------------------------------- */
const H5Z_class2_t ZFP_H5Filter[1] = {{
    H5Z_CLASS_T_VERS,                         /* H5Z_class_t version          */
    (H5Z_filter_t)(ZFP_H5FILTER_ID),          /* Filter id number             */
    1,                                        /* encoder_present flag (set to true) */
    1,                                        /* decoder_present flag (set to true) */
    "HDF5 filter plugin for ZFP compression; see http://computation.llnl.gov/casc/zfp/",
                                              /* Filter name for debugging    */
    (H5Z_can_apply_func_t) H5Z_can_apply_zfp, /* The "can apply" callback     */
    (H5Z_set_local_func_t) H5Z_set_local_zfp, /* The "set local" callback     */
    (H5Z_func_t) H5Z_filter_zfp,              /* The actual filter function   */
}};

H5PL_type_t
H5PLget_plugin_type(void)
{
  return H5PL_TYPE_FILTER;
}

const void*
H5PLget_plugin_info(void)
{
  return ZFP_H5Filter;
}

/*-------------------------------------------------------------------------
 * Function:	H5Z_can_apply_zfp
 *
 * Purpose:	Is filter valid for this dataset?
 *              Before a dataset is created 'can_apply' callback
 *              for any filter used in the dataset creation property list are called.
 *
 * Return:	valid: non-negative
 *              invalid: zero
 *              error: negative
 *
 * Modifications:
 *
 *------------------------------------------------------------------------- */
herr_t
H5Z_can_apply_zfp(hid_t dcpl_id, hid_t type_id, hid_t space_id)
{
    hid_t dclass;
    size_t dsize;
    hid_t dntype;
    size_t ndims;
    unsigned int flags;

    size_t cd_nelmts_in = 5;
    unsigned int cd_values_in[]  = {0,0,0,0,0};

    /* check object identifier */
    /* ----------------------- */

    /* Check if object exists as datatype - try to get pointer to memory referenced by id */
    //if(NULL==H5I_object_verify(type_id, H5I_DATATYPE)) { /* private HDF5 function, not equivalent with H5Iobject_verify()! */
    if(H5Iis_valid(type_id)) {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid type");
      return -1;
    }

#ifndef NDEBUG
    /* TODO: print datatype name if debug-mode
    // check datatype name
    ssize_t dname_size = 0;
    if(0 >= (dname_size = H5Iget_name(type_id, NULL, 0))) {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid datatype name");
      return -1;
    }
    dname_size = dname_size+1;
    char dname[dname_size];
    H5Iget_name( type_id, (char *)(&dname), (size_t)dname_size );
    fprintf(stdout,"   H5Z_can_apply_zfp: dname = %d, '%.*s' \n",(int)dname_size, (int)dname_size, dname); */
#endif

    /* check datatype ( which describes elements of a dataset ) */
    /* -------------- */

    /* check datatype's class - try to get datatype class identifier
     * typedef enum H5T_class_t {
     * 		H5T_NO_CLASS = -1, // error
     * 		H5T_INTEGER  = 0,  // integer types
     * 		H5T_FLOAT    = 1,  // floating-point types
     */
    if(H5T_NO_CLASS == (dclass = H5Tget_class(type_id))) {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid datatype class");
      return -1;
    }
#ifndef NDEBUG
    fprintf(stdout,"   H5Z_can_apply_zfp: dclass = %d", dclass);
    if(dclass != H5T_FLOAT) {
      fprintf(stdout," ... NOT SUPPORTED => skip compression\n");
      return 0;
    };
    fprintf(stdout,"\n");
#else
    if(dclass != H5T_FLOAT) {return 0;}; // only support floats
#endif

    /* check datatype's native-type - must be double or float */
/*  TODO: this check results in register a new native type instead of test for a type
    dntype = H5Tget_native_type(type_id, H5T_DIR_DESCEND); //H5T_DIR_ASCEND);
    if(     H5T_NATIVE_FLOAT  == dntype) { fprintf(stdout,"\nzfp_h5_can_apply: dntype = %d \n", dntype); }
    else if(H5T_NATIVE_DOUBLE == dntype) { fprintf(stdout,"\nzfp_h5_can_apply: dntype = %d \n", dntype); }
    else {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid datatype type");
    }
*/

    /* check datatype's byte-size per value - must be single(==4) or double(==8) */
    if(0 == (dsize = H5Tget_size(type_id))) {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid datatype size");
      return -1;
    }
#ifndef NDEBUG
    fprintf(stdout,"   H5Z_can_apply_zfp: dsize = %d ", (int)dsize);
    if(dsize != 4 && dsize != 8) {
      fprintf(stdout," ... NOT SUPPORTED => skip compression\n");
      return 0;
    }
    fprintf(stdout,"\n");
#else
    if(dsize != 4 && dsize != 8) { return 0;}; // only support 4byte and 8byte floats
#endif

    /* check chunk    */
    /* -------------- */

    if(0 == (ndims = H5Sget_simple_extent_ndims(space_id))) {
      PUSH_ERR("H5Z_can_apply_zfp", H5E_CALLBACK, "no valid no. space dimensions");
      return -1;
    }
    hsize_t dims[ndims];
    H5Sget_simple_extent_dims(space_id, dims, NULL);

#ifndef NDEBUG
    fprintf(stdout,"   H5Z_can_apply_zfp: ndims = %d ", (int)ndims);
    for (size_t ii=0; ii < ndims; ii++) { fprintf(stdout," %d,",(int)dims[ii]); }
    if(ndims != 1 && ndims != 2 && ndims != 3) {
      fprintf(stdout," ... NOT SUPPORTED => skip compression\n");
      return 0;
    }
    fprintf(stdout,"\n");
#else
    if(ndims != 1 && ndims != 2 && ndims != 3) { return 0;}; // only support 1d, 2d and 3d arrays
#endif

    /* check filter */
    /* ------------ */

    /* get current filter values */
    if(H5Pget_filter_by_id2(dcpl_id, ZFP_H5FILTER_ID,
                            &flags, &cd_nelmts_in, cd_values_in,
                            0, NULL, NULL) < 0) { return -1; }

    /* check no. elements    */
    /* -------------- */
    long dcount = 1;
    int dcount_threshold = cd_values_in[4];
    if(dcount_threshold <= 0) { dcount_threshold = 64; }
    for ( size_t ii=0; ii < ndims; ii++) { dcount = dcount *dims[ii]; }

#ifndef NDEBUG
    fprintf(stdout,"   H5Z_can_apply_zfp: dcount = %ld ", dcount);
    if(dcount < dcount_threshold) {
      fprintf(stdout," ... TOO SMALL => skip compression\n");
      return 0;
    }
    fprintf(stdout,"\n");
#else
    if(dcount < dcount_threshold) { return 0; } // only support datasets with count >= threshold
#endif

#ifndef NDEBUG
    fprintf(stdout,"   H5Z_can_apply_zfp: cd_values = [");
    for (size_t ii=0; ii < cd_nelmts_in; ii++) { fprintf(stdout," %d,",cd_values_in[ii]); }
    fprintf(stdout,"]\n");
#endif
    return 1;

 cleanupAndFail:
    return 0;
}

/*-------------------------------------------------------------------------
 * Function:	H5Z_set_local_zfp
 *              Only called on compression, not on reverse.
 *
 * Purpose:	Set the "local" dataset parameter for data compression to be
 *              the size of the datatype.
 *
 * Return:	Success: Non-negative
 *		Failure: Negative
 *
 * Modifications:
 *
 *------------------------------------------------------------------------- */
herr_t
H5Z_set_local_zfp(hid_t dcpl_id, hid_t type_id, hid_t space_id)
{
    size_t dsize;
    size_t ndims;

    unsigned int flags;
    size_t cd_nelmts = 5;
    size_t cd_nelmts_max = 12;
    unsigned int cd_values_in[]  = {0,0,0,0,0};
    unsigned int cd_values_out[] = {0,0,0,0,0,0,0,0,0,0,0,0};

    /* check datatype's byte-size per value - must be single(==4) or double(==8) */
    if(0 == (dsize = H5Tget_size(type_id))) {
      PUSH_ERR("H5Z_set_local_zfp", H5E_CALLBACK, "no valid datatype size");
      return -1;
    }

    /* check chunk    */
    /* -------------- */

    if(0 == (ndims = H5Sget_simple_extent_ndims(space_id))) {
      PUSH_ERR("H5Z_set_local_zfp", H5E_CALLBACK, "no valid no. space dimensions");
      return -1;
    }
    hsize_t dims[ndims];
    H5Sget_simple_extent_dims(space_id, dims, NULL);

    /* check filter */
    /* ------------ */

    /* get current filter values */
    if(H5Pget_filter_by_id2(dcpl_id, ZFP_H5FILTER_ID,
                            &flags, &cd_nelmts, cd_values_in, /*cd_nelmts (inout) */
                            0, NULL, NULL) < 0) { return -1; }

    /* correct number of parameters and fill missing with defaults */
    //    ignore value-ids larger 5
    //    add zero for non-existent value-ids <= 4
    //    add default threshold for value-id == 5
    if(cd_nelmts != 5) {
        if(cd_nelmts < 5) cd_values_in[4] = 64;    // set default threshold = 64 (already used and not required any more, anyway)
        if(cd_nelmts < 4) cd_values_in[3] = -1074; // set default minexp    = -1074
        if(cd_nelmts < 3) cd_values_in[2] = 0;     // set default maxprec   = 0  (set default in compression filter)
        if(cd_nelmts < 2) cd_values_in[1] = 0;     // set default maxbits   = 0  (set default in compression filter)
        if(cd_nelmts < 1) cd_values_in[0] = 0;     // set default minbits   = 0  (set default in compression filter)
        cd_nelmts = 5;
    }

    /* modify cd_values to pass them to filter-func */
    /* -------------------------------------------- */

    // First 4+ndims slots reserved. Move any passed options to higher addresses.
    size_t valshift = 4 +ndims;
    for (size_t ii = 0; ii < cd_nelmts && ii +valshift < cd_nelmts_max; ii++) {
        cd_values_out[ii + valshift] = cd_values_in[ii];
    }

    int16_t version = ZFP_VERSION;
    cd_values_out[0] = version >> 4;      /* major version */
    cd_values_out[1] = version & 0x000f;  /* minor version */
    cd_values_out[2] = dsize;             /* bytes per element */
    cd_values_out[3] = ndims;             /* number of dimensions */
    for (size_t ii = 0; ii < ndims; ii++)
      cd_values_out[ii +4] = dims[ii];    /* size of dimensions */

    cd_nelmts = cd_nelmts + valshift;

    if(H5Pmodify_filter(dcpl_id, ZFP_H5FILTER_ID, flags, cd_nelmts, cd_values_out)) {
      PUSH_ERR("H5Z_set_local_zfp", H5E_CALLBACK, "modify filter not possible");
      return -1;
    }

    return 1;

 cleanupAndFail:
    return 0;
}

/*-------------------------------------------------------------------------
 * Function:	H5Z_filter_zfp
 *
 * Purpose:	Only called if data in dataset (not if only zeros)
 *
 * Return:	Zero on failure
 *
 * Modifications:
 *
 *------------------------------------------------------------------------- */
size_t
H5Z_filter_zfp(unsigned int flags,
               size_t cd_nelmts,               // config data elements
               const unsigned int cd_values[], // config data values
               size_t nbytes,                  // number of bytes
               size_t *buf_size,               // buffer size
               void **buf)                     // buffer
{
    unsigned int zfp_major_ver, zfp_minor_ver;
    size_t dsize;
    size_t ndims;

    size_t buf_size_out = -1;
    size_t nbytes_out = -1;
    bool dp = false;

    void* tmp_buf = NULL;
    void* zfp_buf = NULL;
    void* out_buf = NULL;

    /* get config values */
    //  - from H5Z_set_local_zfp(..) on compression
    //  - from chunk-header on reverse
    if (cd_nelmts < 4) {
        PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "Not enough parameters.");
        return 0;
    }
    zfp_major_ver = cd_values[0];  /* not used - we could add it to the header ? */
    zfp_minor_ver = cd_values[1];  /* not used - we could add it to the header ? */
    dsize         = cd_values[2];  /* bytes per element */
    ndims         = cd_values[3];  /* number of dimensions */
    hsize_t dims[ndims];
    for (size_t ii = 0; ii < ndims; ii++)
      dims[ii] = cd_values[ii +4]; /* size of dimensions */

    /* get size of out_buf
    -----------------------*/

    // size of floating-point type in bytes
    if(dsize == 8) { dp = true; }
    else if(dsize == 4) {dp = false; }
    else {
      PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "unknown precision type");
      return 0;
    }
    size_t typesize = dp ? sizeof(double) : sizeof(float);

    // effective array dimensions
    uint nx = 0;
    uint ny = 0;
    uint nz = 0;
    if(ndims > 0) nx = dims[0];
    if(ndims > 1) ny = dims[1];
    if(ndims > 2) nz = dims[2];

    // initialize zfp parameters
    zfp_params params;
    zfp_init(&params);
    zfp_set_type(&params, dp ? ZFP_TYPE_DOUBLE : ZFP_TYPE_FLOAT);
    if(ndims > 0) zfp_set_size_1d(&params, nx);
    if(ndims > 1) zfp_set_size_2d(&params, nx, ny);
    if(ndims > 2) zfp_set_size_3d(&params, nx, ny, nz);

    // decompress data
    if (flags & H5Z_FLAG_REVERSE) {

        // read 16byte header = (minbits, maxbits, maxprec, minexp)
        tmp_buf = *buf;
        params.minbits = zfp_read_uint32((char*) tmp_buf + 0);
        params.maxbits = zfp_read_uint32((char*) tmp_buf + 4);
        params.maxprec = zfp_read_uint32((char*) tmp_buf + 8);
        params.minexp  = zfp_read_int32 ((char*) tmp_buf +12);

        // allocate for uncompressed
        size_t buf_size_in = std::max(params.nx, 1u)
                           * std::max(params.ny, 1u)
                           * std::max(params.nz, 1u)
                           * ((params.type == ZFP_TYPE_DOUBLE) ? sizeof(double) : sizeof(float));
        out_buf = malloc(buf_size_in);
        if (out_buf == NULL) {
          PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "Could not allocate output buffer.");
          return 0;
        }

#ifndef NDEBUG
        fprintf(stdout, "   H5Z_filter_zfp: decompress: [%d, (%d, %d, %d), %d, %d, %d, %d] = %d \n",
                dp, nx, ny, nz,
                params.minbits, params.maxbits, params.maxprec, params.minexp,
                (int)buf_size_in);
#endif

        // buf[16+] -> out_buf
        zfp_buf = (char*) tmp_buf +16;

        /* decompress 1D, 2D, or 3D floating-point array */
        // int                         /* nonzero on success */
        // zfp_decompress(
        //   const zfp_params* params, /* array meta data and compression parameters */
        //   void* out,                /* decompressed floating-point data */
        //   const void* in,           /* compressed stream */
        //   size_t insize             /* bytes allocated for compressed stream */
        // );
        if (zfp_decompress(&params, out_buf, zfp_buf, buf_size_in) == 0) {
           PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "decompression failed");
           free(out_buf);
           return 0;
        }
        nbytes_out = buf_size_in;

    // compress data
      } else {

        // compression parameter (0 == no compression)
        uint minbits = cd_values[4+ndims +0]; // minimum number of bits per 4^d values in d dimensions (= maxbits for fixed rate)
        uint maxbits = cd_values[4+ndims +1]; // maximum number of bits per 4^d values in d dimensions
        uint maxprec = cd_values[4+ndims +2]; // maximum number of bits of precision per value (0 for fixed rate)
        int  minexp  = cd_values[4+ndims +3]; // minimum bit plane coded (soft error tolerance = 2^minexp; -1024 for fixed rate)

        // correct compression parameters if zero initialized
        uint blocksize = 1u << (2 * ndims); // number of floating-point values per block
        if(minbits <= 0 || minbits > 4096) minbits = blocksize * CHAR_BIT * typesize;    // {1, ..., 4096}     == 12 bits
        if(maxbits <= 0 || maxbits > 4096) maxbits = blocksize * CHAR_BIT * typesize;    // {1, ..., 4096}     == 12 bits
        if(maxprec <= 0 || maxprec > 64)   maxprec = CHAR_BIT * typesize;                // {1, ..., 64}       ==  6 bits
        if(minexp  < -1074) minexp = -1074;                                              // {-1074, ..., 1023} ==  12 bits
        if(minexp  >  1023) minexp =  1023;

        // set compression parameters
        params.minbits = minbits;
        params.maxbits = maxbits;
        params.maxprec = maxprec;
        params.minexp  = minexp;

        // max.(!) size of compressed data
        size_t buf_size_maxout = zfp_estimate_compressed_size(&params);
        if (buf_size_maxout == 0) {
          std::cerr << "invalid compression parameters" << std::endl;
          return 0;
        }

        // allocate for header + compressed data
        tmp_buf = malloc(buf_size_maxout +16);
        if (tmp_buf == NULL) {
          PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "Could not allocate output buffer.");
          return 0;
        }

        // ptr to data (skipping header)
        zfp_buf = (char*) tmp_buf +16;

        /* compress 1D, 2D, or 3D floating-point array */
        // size_t                      /* byte size of compressed stream (0 on failure) */
        // zfp_compress(
        //  const zfp_params* params, /* array meta data and compression parameters */
        //  const void* in,           /* uncompressed floating-point data */
        //  void* out,                /* compressed stream (must be large enough) */
        //  size_t outsize            /* bytes allocated for compressed stream */
        // );
        buf_size_out = zfp_compress(&params, *buf, zfp_buf, buf_size_maxout);
        if (buf_size_out == 0) {
          PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "compression failed");
          free(out_buf);
          return 0;
        }

#ifndef NDEBUG
        fprintf(stdout, "   H5Z_filter_zfp: compress(out): [%d, (%d, %d, %d), %d, %d, %d, %d] = %d \n",
                dp, nx, ny, nz,
                params.minbits, params.maxbits, params.maxprec, params.minexp,
                (int)buf_size_out);
#endif

        // add 32byte header = (minbits, maxbits, maxprec, minexp)
        zfp_write_uint32((char*) tmp_buf + 0, (uint32_t) minbits);
        zfp_write_uint32((char*) tmp_buf + 4, (uint32_t) maxbits);
        zfp_write_uint32((char*) tmp_buf + 8, (uint32_t) maxprec);
        zfp_write_int32 ((char*) tmp_buf +12, ( int32_t) minexp);

        nbytes_out = buf_size_out +16;

        // realloc (free partly) if required
        if(buf_size_out < buf_size_maxout) {
          out_buf = realloc(tmp_buf, nbytes_out); // free out_buf partly (which was not used by ZFP::compress(..))
          if (out_buf == NULL) {
            PUSH_ERR("H5Z_filter_zfp", H5E_CALLBACK, "Could not reallocate output buffer.");
            return 0;
          }
        } else {
            out_buf = tmp_buf;
        }
    }

    /* flip buffer and return
    -------------------------*/
    free(*buf);
    *buf = out_buf;
    *buf_size = nbytes_out;

    return nbytes_out;
}

/*-------------------------------------------------------------------------
 * Function:	H5Z_register_zfp
 *
 * Purpose:
 *
 * Return:
 *
 * Modifications:
 *
 *------------------------------------------------------------------------- */
int
H5Z_register_zfp(void)
{
}
