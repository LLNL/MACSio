/*********************************************************************************************
 *  Copyright (c) 2014-2015, RWTH Aachen University, JARA - Juelich Aachen Research Alliance.
 *  Produced at the RWTH Aachen University, Germany.
 *  Written by Jens Henrik Göbbert (goebbert@jara.rwth-aachen.de)
 *  All rights reserved.
 *
 *  This file is part of the H5zfp library.
 *  For details, see http://www.jara.org/de/research/jara-hpc/.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the disclaimer below.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the disclaimer (as noted below) in the
 *  documentation and/or other materials provided with the distribution.
 *
 *  3. Neither the name of the University nor the names of its contributors may
 *  be used to endorse or promote products derived from this software without
 *  specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************************************/
#ifndef ZFP_H5FILTER_H
#define ZFP_H5FILTER_H

#define H5Z_class_t_vers 2
#include "hdf5.h"

#define ZFP_H5FILTER_ID 299

#ifdef __cplusplus
extern "C" {
#endif

// Prototypes
H5PL_type_t H5PLget_plugin_type(void);

const void* H5PLget_plugin_info(void);

htri_t H5Z_can_apply_zfp(hid_t dcpl_id,          /* dataset creation property list */
                                hid_t type_id,   /* datatype */
                                hid_t space_id); /* a dataspace describing a chunk */

herr_t H5Z_set_local_zfp(hid_t dcpl_id,          /* dataset creation property list */
                                hid_t type_id,   /* datatype */
                                hid_t space_id); /* dataspace describing the chunk */

size_t H5Z_filter_zfp(unsigned int flags,
                             size_t cd_nelmts,
                             const unsigned int cd_values[],
                             size_t nbytes,
                             size_t *buf_size,
                             void **buf);

int H5Z_register_zfp(void);

#ifdef __cplusplus
} // closing brace for extern "C"
#endif

// Utilities for read/write header

/* write a 64 bit unsigned integer to a buffer in big endian order. */
void zfp_write_uint64(void* buf, uint64_t num) {
    uint8_t* b = static_cast<uint8_t*>(buf);
    uint64_t pow28 = (uint64_t)1 << 8;
    for (int ii = 7; ii >= 0; ii--) {
        b[ii] = num % pow28;
        num = num / pow28;
    }
}

/* read a 64 bit unsigned integer from a buffer big endian order. */
uint64_t zfp_read_uint64(void* buf) {
    uint8_t* b = static_cast<uint8_t*>(buf);
    uint64_t num = 0, pow28 = (uint64_t)1 << 8, cp = 1;
    for (int ii = 7; ii >= 0; ii--) {
        num += b[ii] * cp;
        cp *= pow28;
    }
    return num;
}

/* write a 64 bit signed integer to a buffer in big endian order. */
void zfp_write_int64(void* buf, int64_t num) {
    uint64_t pow2x = (uint64_t)1 << 63;
    uint64_t num_uint = (num + pow2x);
    zfp_write_uint64(buf, num_uint);
}

/* read a 64 bit signed integer from a buffer big endian order. */
int64_t zfp_read_int64(void* buf) {
    uint64_t num_uint = zfp_read_uint64(buf);
    uint64_t pow2x = (uint64_t)1 << 63;
    return (num_uint -pow2x);
}

/* write a 32 bit unsigned integer to a buffer in big endian order. */
void zfp_write_uint32(void* buf, uint32_t num) {
    uint8_t* b = static_cast<uint8_t*>(buf);
    uint32_t pow28 = (uint32_t)1 << 8;
    for (int ii = 3; ii >= 0; ii--) {
        b[ii] = num % pow28;
        num = num / pow28;
    }
}

/* read a 32 bit unsigned integer from a buffer big endian order. */
uint32_t zfp_read_uint32(void* buf) {
    uint8_t* b = static_cast<uint8_t*>(buf);
    uint32_t num = 0, pow28 = (uint32_t)1 << 8, cp = 1;
    for (int ii = 3; ii >= 0; ii--) {
        num += b[ii] * cp;
        cp *= pow28;
    }
    return num;
}

/* write a 32 bit signed integer to a buffer in big endian order. */
void zfp_write_int32(void* buf, int32_t num) {
    uint32_t pow2x = (uint32_t)1 << 31;
    uint32_t num_uint = (num + pow2x);
    zfp_write_uint32(buf, num_uint);
}

/* read a 32 bit signed integer from a buffer big endian order. */
int32_t zfp_read_int32(void* buf) {
    uint32_t num_uint = zfp_read_uint32(buf);
    uint32_t pow2x = (uint32_t)1 << 31;
    return (num_uint -pow2x);
}

#endif // ZFP_H5FILTER_H
