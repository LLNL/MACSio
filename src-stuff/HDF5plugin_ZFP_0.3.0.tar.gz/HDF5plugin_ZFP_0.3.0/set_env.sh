#!/bin/sh

BASE=`pwd`

export ZFP_ROOT=${BASE}/zfp/zfp-0.3.0
export HDF5_ROOT=${BASE}/hdf5/hdf5-1.8.14_gcc48_patched

export HDF5_PLUGIN_PATH=${HDF5_ROOT}/lib/plugin

export PATH=${HDF5_ROOT}/bin/:${PATH}
export LD_LIBRARY_PATH=${HDF5_ROOT}/lib/:$LD_LIBRARY_PATH
