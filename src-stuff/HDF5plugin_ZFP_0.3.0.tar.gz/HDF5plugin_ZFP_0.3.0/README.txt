============================================================================================
hdf5plugin_ZFP is a compression filter for HDF5 using the algorithm and lib 'zfp' of Peter Lindstrom
It enables the use of ZFP compression for floating point (single/double precision) 2d and 3d arrays and will be dynamically loaded as HDF5 plugin at runtime by the HDF5 library.

ZFP compression lib by Peter Lindstrom:
  zfp is an open source C++ library for compressed floating-point arrays that support both read and write random access.
  zfp was written by Peter Lindstrom at Lawrence Livermore National Laboratory and can be downloaded from https://computation.llnl.gov/casc/zfp
  zfp 0.2.1 is part of this package
  zfp was designed to achieve high compression ratios of floating-point data, and therefore employs lossy but optionally error-bounded compression.
  Although bit-for-bit lossless compression is not always possible, zfp can approach almost perfectly lossless compression for most data sets.

More about HDF5 filers can be found at
  a) http://www.hdfgroup.org/HDF5/doc/H5.user/Filters.html
  b) http://www.hdfgroup.org/HDF5/doc/Advanced/DynamicallyLoadedFilters/HDF5DynamicallyLoadedFilters.pdf
  c) http://www.hdfgroup.org/ftp/HDF5/examples/howto/compression/Topic-4.2-DatasetFilters.pptx

Requirements,
  Building this ZFP compression filter for HDF5 requires CMake.
  It also requires knowledge of the hdf5 installation and minimum of HDF5.
    CMake (>=2.8.10), http://www.cmake.org
    HDF5  (>=1.8.12 build with cmake), http://www.hdfgroup.org

Howto use,
  hdf5plugin_ZFP is a compression filter, which will be dynamically loaded at runtime by the HDF5 library.
  It can be used with the HDF5 tool 'h5repack' to compress existing HDF5 files,
  but can also be used directly from any application (currently HDF5 filters are only supported by serial HDF5 and not parallel HDF5).

  compress using ZFP:
    h5repack -v -f UD=299,5,<minbits>,<maxbits>,<maxprec>,<minexp>,<threshold> <infile.h5> <ZFPcompressed.h5>
    minbits = 0     : min # bits per 4^d values in d dimensions (= maxbits for fixed rate) {1, ..., 4096}
            (default<=0: double array(1d,2d,3d): 4*64, 16*64, 64*64
                          float array(1d,2d,3d): 4*32, 16*32, 64*32)
    maxbits = 256   : max # bits per 4^d values in d dimensions (= minbits for fixed rate) {1, ..., 4096}
            (default<=0: double array(1d,2d,3d): 4*64, 16*64, 64*64
                          float array(1d,2d,3d): 4*32, 16*32, 64*32)
    maxprec = 32    : max # bits of precision per value (0 for fixed rate)
            (default<=0: 64 for 8byte-floats, 32 for 4byte-floats)
    minexp  = -1074 : min bit plane coded (error tolerance = 2^minexp; -1024 for fixed rate)
            (default<=-1074)
    thresh  = 512   : min. number of floats in dataset to allow compression
            (default<=0: 64)
  decompress using ZFP:
    h5repack -v --filter=NONE  <ZFPcompressed.h5> <outfile.h5>

This plugin has been tested on Linux only, but should work for Windows, too.

== detailed install instructions ==========================================================================================

Prepare HDF5,
    1) configure+build+install CMake to <CMAKE-INSTPATH>
      ./configure --prefix=<CMAKE-INSTPATH>
      make && make install
      export PATH=<CMAKE-INSTPATH>/bin/:${PATH}

    2) patch HDF5
      !!! ATTENTION !!!
      h5repack <= 1.8.14 has a bug in its command line parser (test 2 will fail).
      The bug has been reported and will probably be fixed in 1.8.15.
      The patch can be found in hdf5plugin_ZFP/patch/.
      This patch enables the easy use of h5repack as described in test 2.
          patch <HDF5-SOURCEPATH>/tools/h5repack/h5repack_parse.c < <HDF5PLUGIN_ZFP>/patch/h5repack_parse.patch

    3) configure HDF5 (using cmake(!))
      cd <HDF5-SOURCEPATH>
      mkdir build; cd build
      ccmake ..
          set {CMAKE_INSTALL_PREFIX}   == "<HDF5-INSTPATH>"
          set {HDF5_BUILD_TOOLS}       == "ON"
          set {HDF5_ENABLE_PARALLEL}   == "OFF" (filters are not supported for parallel HDF5, yet)

    4) build and install HDF5
      make
      make install

Prepare libZFP,
    5) build static library libzfp.a (minimum 0.3.0)
      cd <ZFP_SOURCES>/src
      make

Build,
    6) set enviroment vars
      export ZFP_ROOT=<ZFP_ROOT_DIR>
      export HDF5_ROOT=<HDF5-INSTPATH>
      export PATH=${HDF5_ROOT}/bin/:${PATH}
      export LD_LIBRARY_PATH=${HDF5_ROOT}/lib/:$LD_LIBRARY_PATH

    7) configure hdf5plugin_ZFP
      cd hdf5plugin_ZFP
      mkdir build; cd build
      ccmake ..
          set {CMAKE_INSTALL_PREFIX} to "<HDF5-INSTPATH>"

    8) build and install
      make
      make install

Test,
    9) set enviroment vars for HDF5
      export HDF5_ROOT=<HDF5-INSTPATH>
      export PATH=${HDF5_ROOT}/bin/:${PATH}
      export LD_LIBRARY_PATH=${HDF5_ROOT}/lib/:$LD_LIBRARY_PATH

   10) set PLUGIN search path (!!)
      export HDF5_PLUGIN_PATH=${HDF5_ROOT}/lib/plugin/

   11) test 1: pack+unpack test data with default settings
      cd hdf5plugin_ZFP
      h5repack -v -f UD=299,1,0 test/test.h5 test_compr.h5
      h5repack -v --filter=NONE test_compr.h5 test_uncomp.h5

   12) test 2: pack+unpack test data with user defined settings
       !!! ATTENTION !!!
       h5repack <= 1.8.14 has a bug in its command line parser. Have you applied the patch, when installing HDF5?
      h5repack -v -f UD=299,5,0,256,32,-16,512 test/test.h5 test_compr.h5
      h5repack -v --filter=NONE test_compr.h5 test_uncomp.h5

More,
    10) Read HDF5DynamicallyLoadedFilters.pdf for more information on dynamically loaded filters and how to use them in applications.
